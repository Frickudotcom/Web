## PHPVibe Video CMS
# PHPVibe Free Video Sharing CMS 

The modern choice of design inspired by Youtube and a social videos sharing module that may just cut it for your video portal


![PHPVibe](https://github.com/PHPVibe/phpvibe/blob/master/vlst-1220x625.png)



PHPVibe lite takes care of the many needs your new video portal will challenge you with, but doesn’t save any video on your hosting!
Don’t worry there is still tons of features to enjoy! It has all the features of the MediaVibe CMS (PHPVibe PRO) except the video upload and ffmpeg conversion, the image sharing and music components.

It comes bundled with the powerful Youtube importer and automated tasks for it. All the video sources (link shared videos with automated embed generator) and a link to mp4 (for remotely hosted video files).

Read more: https://www.phpvibe.com/phpvibe/
Installing: https://www.phpvibe.com/installing-phpvibe/
Requirements: https://www.phpvibe.com/requirements/
Plugins: https://phpvibes.com/addons?id=2
